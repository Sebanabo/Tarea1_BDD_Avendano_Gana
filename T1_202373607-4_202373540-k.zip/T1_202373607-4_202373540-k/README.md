T1_202373607-4_202373540-k

Nombre: Sebastián Avendaño / Rol: 202373607-4
Nombre: Javier Gana / Rol: 202373540-k

Instrucciones:
En un BDMS (Nosotros ocupamos SQL Server Management Studio):
1- Ejecute archivo "tablas.sql"
2- Ejecute archivo "inserts.sql"
3- Ejecute archivo "consultas.sql"

Supuestos:
-Si se elimina una solicitud, también se elimina esa asignación a Ingeniero.
-Un ingeniero puede no tener asignaciones.
-Un Usuario puede no hacer Solicitudes
-Pueden Haber solicitudes sin ingenieros asignados por falta de cantidad de ingenieros.

Notas:
A la tabla "Funcionalidad" Correspondiente a las solicitudes de Funcionalidad, añadimos el atributo "Fecha".